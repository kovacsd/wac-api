package kr.scramban.wac.parser.order;


public class DummyOrderParser implements OrderParser {

    @Override
    public String parse(final String[][] args) {
        return null;
    }
}