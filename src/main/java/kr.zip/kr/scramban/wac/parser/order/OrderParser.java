package kr.scramban.wac.parser.order;


public interface OrderParser {

    String parse(String[][] args);
}
