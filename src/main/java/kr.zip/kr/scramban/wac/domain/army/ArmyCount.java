package kr.scramban.wac.domain.army;

public class ArmyCount {

    private int reinforcement = 0;

    public int getReinforcement() {
        return reinforcement;
    }

    public void setReinforcement(final int reinforcement) {
        this.reinforcement = reinforcement;
    }
}
